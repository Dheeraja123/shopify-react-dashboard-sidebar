import React, {useState , useEffect } from 'react';
import { Link, NavLink ,useLocation,useMatch} from 'react-router-dom';
import { SiShopware } from 'react-icons/si';
import { MdOutlineCancel } from 'react-icons/md';
import { TooltipComponent } from '@syncfusion/ej2-react-popups';
import { MdKeyboardArrowRight } from 'react-icons/md';
import { links } from '../data/dummy';
import { useStateContext } from '../contexts/ContextProvider';



const SidebarMain = () => {
  const [expandedSubMenu, setExpandedSubMenu] = useState();
  const { currentColor, activeMenu, setActiveMenu, screenSize,activeMenuSub, setActiveMenuSub  } = useStateContext();
  let location = useLocation();

  console.log(location.pathname.replaceAll("%20"," "));
  let s2 = location.pathname.substring(1);
let sub_string = s2.replaceAll("%20"," ");
console.log(sub_string,"string");
  // Use the array of keys which contain an object named "Unique"


  const activeLink = 'flex items-center gap-5 pl-4 pt-3 pb-2.5 rounded-lg  text-white  text-md m-2';
  const normalLink = 'flex items-center gap-5 pl-4 pt-3 pb-2.5 rounded-lg text-md text-gray-700 dark:text-gray-200 dark:hover:text-black hover:bg-light-gray m-2';

  return (
    <div className="ml-3 h-screen md:overflow-hidden overflow-auto md:hover:overflow-auto pb-10">
    
        <>
          <div className="flex justify-between items-center">
           
          </div>
          <div className="mt-10 ">
            {links.map((item) => (
              <div key={item.title}>
            
                {item.links.map((link) => (JSON.stringify(link).includes(sub_string) && link.submenu?.length>0 && sub_string.length > 1) ? (
               
            <div className='dis-block'>  {link.submenu?.map((linker) => (<>
           
                  <NavLink
                  to={`/${linker.name2}`}
                  key={linker.name}

                  style={({ isActive }) => ({
                    backgroundColor: isActive ? currentColor : '',
                  })}
                  className={({ isActive }) => (isActive ? activeLink : normalLink)}
                >
                  {linker.icon}
                  <span className="capitalize ">{linker.name}</span>
                </NavLink>
                  </>  
                  ))}</div>
                  
                ):null)}
                
               
              
              </div>
            ))}
          </div>
        </>
      
    </div>
  );
};

export default SidebarMain;
