import React from 'react';
import { useLocation} from 'react-router-dom'; 


const Cloud = () => {
    let location = useLocation();
    console.log(location);
    let s2 = location.pathname.substring(1);
  let sub_string = s2.replaceAll("%20"," ");
  return (
  <div className="mt-24">
    <p className="dark:text-gray-200 text-gray-700 text-center m-20">
    Welcome {sub_string} to view this page
    </p>
  </div>
  )
};

export default Cloud;
