

# Getting Started
These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

Prerequisites
Before you start, make sure you have the following software installed on your computer:

Node.js
npm (Node Package Manager)


## 🛠 Skills
Javascript, HTML, CSS, React.JS, and TailwindCSS.


## How to use this Repository?

1. Clone the repository to your local machine

```bash
  git clone https://github.com/omunite215/React-Admin-DashBoard.git

```
2. Navigate to the project directory

```bash
  cd React-Admin-DashBoard
```
3. Install the necessary dependencies
```bash
  npm install
```

4. Start the development server
```bash
  npm start
```

The website should now be up and running on http://localhost:3000.

## Built With:

- React - A JavaScript library for building user interfaces
- Tailwind - A Modern CSS Framework.
- HTML - Standard markup language for creating web pages
- CSS - Style sheet language used for describing the look and formatting of a document written in HTML
- React Context API -  allows us to pass data through our component trees, giving our components the ability to communicate and share data at different levels.

## Features

- Light and Dark Mode.
- Theme Color Options.
- Responsive.
- Beautiful UI.
- Beautiful Graphs created using Syncfusion


## Tech Stack

**Client:** React, TailwindCSS, Syncfusion

**Server:** Netlify




